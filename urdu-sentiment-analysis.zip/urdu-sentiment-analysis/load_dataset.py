"""
Roman Urdu Sentiment Analysis - Dataset Loader
Dataset: https://www.kaggle.com/datasets/owaisraza009/roman-urdu-dataset
"""

import os
import zipfile
import pandas as pd

DATASET_DIR = "data"
DATASET_SLUG = "owaisraza009/roman-urdu-dataset"
CSV_NAME = "Roman Urdu DataSet.csv"


def download_dataset():
    """Download dataset from Kaggle using kaggle API."""
    print("Downloading dataset from Kaggle...")
    os.makedirs(DATASET_DIR, exist_ok=True)

    # Check kaggle.json exists
    kaggle_path = os.path.join(os.path.expanduser("~"), ".kaggle", "kaggle.json")
    if not os.path.exists(kaggle_path):
        print("\n[ERROR] kaggle.json not found!")
        print("Steps to fix:")
        print("  1. Go to https://www.kaggle.com -> Account -> API -> Create New Token")
        print("  2. Download kaggle.json")
        print("  3. Place it at:  ~/.kaggle/kaggle.json")
        print("  4. Run this script again\n")
        raise FileNotFoundError("kaggle.json missing")

    os.system(
        f"kaggle datasets download -d {DATASET_SLUG} -p {DATASET_DIR} --unzip"
    )
    print("Download complete.")


def load_data(csv_path=None):
    """Load and clean the Roman Urdu dataset. Returns a DataFrame with columns: text, sentiment."""

    if csv_path is None:
        csv_path = os.path.join(DATASET_DIR, CSV_NAME)

    if not os.path.exists(csv_path):
        download_dataset()

    # Dataset has 3 columns — first is junk index, second is sentiment, third is text
    df = pd.read_csv(csv_path, encoding="utf-8", header=None)

    # Auto-detect column layout
    if df.shape[1] == 3:
        df = df.iloc[:, 1:3]
        df.columns = ["sentiment", "text"]
    elif df.shape[1] == 2:
        df.columns = ["sentiment", "text"]
    else:
        raise ValueError(f"Unexpected number of columns: {df.shape[1]}")

    # Drop nulls and duplicates
    df.dropna(inplace=True)
    df.drop_duplicates(inplace=True)

    # Normalize labels
    df["sentiment"] = df["sentiment"].str.strip().str.capitalize()
    valid_labels = ["Positive", "Negative", "Neutral"]
    df = df[df["sentiment"].isin(valid_labels)]

    df.reset_index(drop=True, inplace=True)
    print(f"Dataset loaded: {len(df)} samples")
    print(df["sentiment"].value_counts())
    return df


if __name__ == "__main__":
    df = load_data()
    print(df.head())
